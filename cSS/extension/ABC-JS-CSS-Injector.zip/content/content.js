'use strict';

var fullPath = window.location.href;

chrome.storage.local.get(null, function(result) {
	var Scripts = result;

	for(var key in Scripts){
		if(key != 'config'){
			if((Scripts[key].Status === undefined || Scripts[key].Status != 'Inactive') && Scripts[key].ExecType == 0){
		    var regex = new RegExp('('+Scripts[key].Domain+')','gim');

		    if(regex.test(fullPath)){
					if(Scripts[key].Type == 'JS'){
						var scriptElm = document.createElement('script');
						scriptElm.innerHTML = Scripts[key].Content;
						document.body.appendChild(scriptElm);
						console.log('Script '+key+' added succesfully!');
					} else if(Scripts[key].Type == 'CSS'){
						var scriptElm = document.createElement('style');
						scriptElm.innerHTML = Scripts[key].Content;
						document.body.appendChild(scriptElm);
						console.log('Style '+key+' added succesfully!');
					}
		    } 
			}
		}
	}
});